package com.example.photosapp.repositories;

import androidx.lifecycle.MutableLiveData;

import com.example.photosapp.models.PhotoModel;

import java.util.List;

public class PhotosRepository {

    public PhotosRepository() {

    }

    private MutableLiveData<List<PhotoModel>> photos;

    public MutableLiveData<List<PhotoModel>> getPhotos(String searchText) {
        photos = new MutableLiveData<>();
        loadPhotos(searchText);
        return photos;
    }

    public void loadPhotos(String searchText) {
        new PhotosFeedHelper(new PhotosCallback() {
            @Override
            public void onFinish(List<PhotoModel> photosList) {

                photos.postValue(photosList);
            }
        }).processPhotos(searchText);
    }
}
