package com.example.photosapp.views;

import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.photosapp.AppConstants;
import com.example.photosapp.R;
import com.example.photosapp.models.PhotoModel;
import com.example.photosapp.viewmodels.MainViewModel;

import java.util.List;

public class MainFragment extends Fragment {

    private MainViewModel mViewModel;
    private View mRootView;

    public static MainFragment newInstance() {
        return new MainFragment();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        mRootView = inflater.inflate(R.layout.main_fragment, container, false);
        return mRootView;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(MainViewModel.class);
        mViewModel.getPhotos("BIRDS").observe(this, new Observer<List<PhotoModel>>() {
            @Override
            public void onChanged(final List<PhotoModel> photoModels) {
                MainAdapter adapter = new MainAdapter(getContext(), photoModels);
                RecyclerView gridView = (RecyclerView) mRootView.findViewById(R.id.grid_view);
                gridView.setHasFixedSize(true);
                StaggeredGridLayoutManager sglm = new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL);
                gridView.setLayoutManager(sglm);
                gridView.setAdapter(adapter);
                gridView.addOnItemTouchListener(new PhotoSelectListener(getContext(), gridView, new PhotoSelectListener.OnItemClickListener() {
                    @Override
                    public void onSelect(View view, int position) {

                        Intent intent = new Intent(getActivity(), PhotoActivity.class);
                        intent.putExtra(AppConstants.EXTRA_URL, photoModels.get(position).getUrl().replace("_m","_b"));
                        startActivity(intent);
                    }

                    @Override
                    public void onLongItemClick(View view, int position) {

                    }
                }));
            }
        });
    }

}
