package com.example.photosapp.viewmodels;

import androidx.lifecycle.ViewModel;

public class PhotoViewModel extends ViewModel {
    // TODO
}
