package com.example.photosapp.repositories;

import com.example.photosapp.models.PhotoModel;

import java.util.List;

public interface PhotosCallback {

    void onFinish(List<PhotoModel> photos);
}
