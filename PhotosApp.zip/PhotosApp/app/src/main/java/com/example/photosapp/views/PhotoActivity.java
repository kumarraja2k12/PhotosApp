package com.example.photosapp.views;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.photosapp.AppConstants;
import com.example.photosapp.R;

public class PhotoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.photo_activity);
        if (savedInstanceState == null) {
            Bundle bundle = new Bundle();
            bundle.putString(AppConstants.EXTRA_URL, getIntent().getExtras().getString(AppConstants.EXTRA_URL));
            PhotoFragment fragment = PhotoFragment.newInstance();
            fragment.setArguments(bundle);
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.container, fragment)
                    .commitNow();
        }
    }
}
