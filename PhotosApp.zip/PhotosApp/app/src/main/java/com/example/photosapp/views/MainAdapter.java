package com.example.photosapp.views;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.photosapp.R;
import com.example.photosapp.models.PhotoModel;
import com.squareup.picasso.LruCache;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class MainAdapter extends RecyclerView.Adapter {

    private Context mContext;
    private List<PhotoModel> photoModels = new ArrayList<>();

    public class PhotosViewHolder extends RecyclerView.ViewHolder {
        public ImageView imageView;
        public TextView positionTextView;

        public PhotosViewHolder(View itemView) {
            super(itemView);
        }
    }

    public MainAdapter(Context context, List<PhotoModel> photoModels) {
        mContext = context;
        this.photoModels = photoModels;
       Picasso p = new Picasso.Builder(mContext)
                .memoryCache(new LruCache(24000))
                .build();
        p.setIndicatorsEnabled(true);
        p.setLoggingEnabled(true);
        Picasso.setSingletonInstance(p);
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int position) {
        View itemView = LayoutInflater.from(mContext).inflate(R.layout.main_grid_item, null);
        PhotosViewHolder holder = new PhotosViewHolder(itemView);
        holder.imageView = (ImageView) itemView.findViewById(R.id.dynamic_height_image_view);
        holder.positionTextView = (TextView) itemView.findViewById(R.id.item_position_view);
        itemView.setTag(holder);
        return holder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int position) {

        PhotosViewHolder vh = (PhotosViewHolder) viewHolder;
        PhotoModel item = photoModels.get(position);
        Picasso.with(mContext).load(item.getUrl()).into(vh.imageView);
    }

    @Override
    public int getItemCount() {
        return photoModels.size();
    }
}
