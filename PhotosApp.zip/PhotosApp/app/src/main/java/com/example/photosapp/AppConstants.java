package com.example.photosapp;

public class AppConstants {

    public static String EXTRA_URL = "url";
}
