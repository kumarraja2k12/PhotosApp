package com.example.photosapp.views;

import androidx.lifecycle.ViewModelProviders;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.example.photosapp.AppConstants;
import com.example.photosapp.R;
import com.example.photosapp.viewmodels.PhotoViewModel;
import com.squareup.picasso.Picasso;

public class PhotoFragment extends Fragment {

    private PhotoViewModel mViewModel;

    public static PhotoFragment newInstance() {
        return new PhotoFragment();
    }

    private View mRootView;
    private String mUrl;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        mUrl = getArguments().getString(AppConstants.EXTRA_URL);
        mRootView = inflater.inflate(R.layout.photo_fragment, container, false);
        return mRootView;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(PhotoViewModel.class);
        ImageView imageViewPhoto = mRootView.findViewById(R.id.image_photo);
        Picasso.with(getContext()).load(mUrl).into(imageViewPhoto);
    }

}
