package com.example.photosapp.repositories;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import android.text.TextUtils;

import com.example.photosapp.models.PhotoModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class PhotosFeedHelper {

    private PhotosCallback photosCallback;

    public PhotosFeedHelper(PhotosCallback callback) {
        photosCallback = callback;
    }

    private static final String FEED_START = "jsonFlickrFeed({";
    private static final CharSequence FEED_END = "})";

    public void processPhotos(String searchText) {
        String url = String.format("https://api.flickr.com/services/feeds/photos_public.gne?format=json&tags=%s", searchText);

        OkHttpClient client = new OkHttpClient();
        final Request request = new Request.Builder().url(url).build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }
            @Override
            public void onResponse(Call call, final Response response) {
                InputStream in = null;
                BufferedReader reader=null;

                try {
                    reader = new BufferedReader(new StringReader(response.body().string()));
                    String json = readJSON(reader);
                    photosCallback.onFinish(parseJSON(json));
                }
                catch(IOException e) {
                    e.printStackTrace();
                }
                finally {
                    closeStreams(in, reader);
                }

            }
        });
    }

    private void closeStreams(InputStream in, BufferedReader reader) {
        try {
            if(in != null) {
                in.close();
            }
            if (reader != null) {
                reader.close();
            }
        }
        catch(IOException e) {
            e.printStackTrace();
        }
    }

    private List<PhotoModel> parseJSON(String json) {
        List<PhotoModel> photos = new ArrayList<>();
        try {
            JSONObject obj = new JSONObject(json);
            JSONArray items = obj.getJSONArray("items");
            String[] urls = new String[items.length()];
            for(int i = 0; i < items.length(); i++) {
                PhotoModel model = new PhotoModel();
                JSONObject objson = items.getJSONObject(i);
                objson = objson.getJSONObject("media");
                String urlString = objson.getString("m");
                if (!TextUtils.isEmpty(urlString)) {
                    model.setUrl(urlString);
                    int width = 150;
                    int height = (int) (50 + Math.random() * 450);
                    //model.setWidth(width);
                    //model.setHeight(height);
                }
                photos.add(model);
            }
        }
        catch(JSONException e) {
            e.printStackTrace();
        }
        return photos;
    }

    private String readJSON(BufferedReader reader) throws IOException {
        StringBuilder sb = new StringBuilder();
        String line = reader.readLine();
        while(line != null)
        {
            if (line.contains(FEED_START)) {
                line = "{";
            } else if (line.contains(FEED_END)) {
                line = "}";
            }
            sb.append(line);
            line = reader.readLine();
        }
        return sb.toString();
    }
}