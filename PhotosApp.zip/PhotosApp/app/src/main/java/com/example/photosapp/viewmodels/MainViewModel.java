package com.example.photosapp.viewmodels;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.MutableLiveData;

import com.example.photosapp.models.PhotoModel;
import com.example.photosapp.repositories.PhotosRepository;

import java.util.List;

public class MainViewModel extends AndroidViewModel {

    PhotosRepository repository;

    public MainViewModel(Application application) {
        super(application);
        repository = new PhotosRepository();
    }

    public MutableLiveData<List<PhotoModel>> getPhotos(String searchText) {
        return repository.getPhotos(searchText);
    }

}
